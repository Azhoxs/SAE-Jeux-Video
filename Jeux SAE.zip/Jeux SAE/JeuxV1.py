from tkinter import *
import tkinter as tk
from PIL import Image, ImageTk
import subprocess


def changer_couleur(event):
    event.widget.config(bg="gray")
    
    
def remetttre_couleur(event):
    event.widget.config(bg="#2d2d2d")


def open_plateau():

    try:
        subprocess.run(["python", "PlateauV2.py"])  
    except Exception as e:
        print(f"An error occurred while running PlateauV2.py: {e}")


def creation_f():
    
    
    # Création d'une fenêtre avec la classe Tk :
    fenetre = Tk()
    
    
    # Met la taille de la fenetre en plein écran :
    fenetre.attributes('-fullscreen', True)
    
    
    # Ajoute une image en fond sur la fenetre :
    fond = PhotoImage(file="./Photos/fond.png")
    can = Canvas(fenetre, width=1920, height=1080)
    can.pack()
    can.create_image(0, 0, anchor=NW, image=fond)
    
    
    # Ajout d'un boutton pour quitter le jeux :
    quitter = Button(fenetre, text="Quitter", command=fenetre.destroy)
    quitter.pack()
    quitter.place(relx=0.5, rely=0.62, anchor="center")

    
    
    # Modifie la taille du bouton la couleur de fond, la couleur du texte et la police :
    quitter.config(height=2, width=50, font=("Arial", 10), bg="#2d2d2d", fg="white")
    quitter.bind("<Enter>", changer_couleur)
    quitter.bind("<Leave>", remetttre_couleur)
    
    
    jouer(fenetre)
    info(fenetre)
    
    
    # Affichage de la fenêtre créée :
    fenetre.mainloop()
    
    
#===============================================================================================
#   Partie pour le plateau du jeux ( création du plateau, déplacement des joueurs, choix joueurs )
#===============================================================================================    
    
number_of_players = 1  # Initialise par défaut, 1 joueur


def jouer (fenetre):
    def nb_j():
        def open_game_window():
    
            nb_j_fenetre.destroy()
            
            
            global number_of_players  # Utilisez la variable globale
            if var1.get() == 1:
                number_of_players = 1
            elif var2.get() == 1:
                number_of_players = 2
            elif var3.get() == 1:
                number_of_players = 3
            elif var4.get() == 1:
                number_of_players = 4
                
            # Open and run the PlateauV2.py script
            open_plateau()
                
                
                
           
                        
                        
#===============================================================================================
# Fenêtre pour le choix des joueurs ( 1, 2, 3 ou 4 joueurs ) 
#===============================================================================================                        

                        
        nb_j_fenetre = tk.Toplevel()
        nb_j_fenetre.title("Choix du nombres de joueurs")

        nb_j_fenetre.attributes('-fullscreen', True)


        fond = PhotoImage(file="./Photos/fond_nbj.png")
        can = Canvas(nb_j_fenetre, width=1920, height=1080)
        can.pack()
        can.create_image(0, 0, anchor=NW, image=fond)
                
        
        # ajoute des case a cocher pour choisir le nombre de joueur :
        
        var1 = IntVar()
        var2 = IntVar()
        var3 = IntVar()
        var4 = IntVar()
        
        
        case1 = Checkbutton(nb_j_fenetre, text="1 joueur", variable=var1, onvalue=1, offvalue=0, height=2, width=10)
        case1.pack()
        case1.place(relx=0.5, rely=0.4, anchor="center")
        case1.config(font=("Arial", 10),bg="#2d2d2d", fg="#909090")
        
        
        case2 = Checkbutton(nb_j_fenetre, text="2 joueurs", variable=var2, onvalue=1, offvalue=0, height=2, width=10)
        case2.pack()
        case2.place(relx=0.5, rely=0.5, anchor="center")
        case2.config(font=("Arial", 10),bg="#2d2d2d", fg="#909090")
        
        
        case3 = Checkbutton(nb_j_fenetre, text="3 joueurs", variable=var3, onvalue=1, offvalue=0, height=2, width=10)
        case3.pack()
        case3.place(relx=0.5, rely=0.6, anchor="center")
        case3.config(font=("Arial", 10),bg="#2d2d2d", fg="#909090")
        
        
        case4 = Checkbutton(nb_j_fenetre, text="4 joueurs", variable=var4, onvalue=1, offvalue=0, height=2, width=10)
        case4.pack()
        case4.place(relx=0.5, rely=0.7, anchor="center")
        case4.config(font=("Arial", 10),bg="#2d2d2d", fg="#909090")
        
        
        # ajouter un bouton pour valider le nombre de joueur :
        
        valider = Button(nb_j_fenetre, text="Valider", command=open_game_window)
        valider.pack()
        valider.place(relx=0.5, rely=0.8, anchor="center")
        valider.config(height=2, width=50, font=("Arial", 10), bg="#2d2d2d", fg="white")
        valider.bind("<Enter>", changer_couleur)
        valider.bind("<Leave>", remetttre_couleur)
        
        # ajouter un bouton retour pour fermer la fenetre ng_j_fenetre :
        
        retour = Button(nb_j_fenetre, text="Retour", command=nb_j_fenetre.destroy)
        retour.pack()
        retour.place(relx=0.5, rely=0.9, anchor="center")
        retour.config(height=2, width=50, font=("Arial", 10), bg="#2d2d2d", fg="white")
        retour.bind("<Enter>", changer_couleur)
        retour.bind("<Leave>", remetttre_couleur)
        
        nb_j_fenetre.mainloop()
        
        
            
    jouer = Button(fenetre, text="Jouer", font=("Arial", 20), command=nb_j)
    jouer.pack()
    jouer.place(relx=0.5, rely=0.5, anchor="center")
    jouer.config(height=2, width=50, font=("Arial", 10), bg="#2d2d2d", fg="white")
    jouer.bind("<Enter>", changer_couleur)
    jouer.bind("<Leave>", remetttre_couleur)

def info(fenetre):
    def ouvrir_info():
        fenetre.destroy()  # Ferme la fenêtre principale
        creation_info()  # Appelle la fonction creation_info pour afficher la fenêtre d'informations
        

    info_button = Button(fenetre, text="Informations", command=ouvrir_info, font=("Arial", 20))
    info_button.pack()
    info_button.place(relx=0.5, rely=0.56, anchor="center")
    info_button.config(height=2, width=50, font=("Arial", 10), bg="#2d2d2d", fg="white")
    info_button.bind("<Enter>", changer_couleur)
    info_button.bind("<Leave>", remetttre_couleur)
    
    
    
#================================================================================================    
#   Partie pour les informations ( règles, biomes, cartes )
#================================================================================================
    
    
    
def creation_info():
    
    def fermer_info():
        fenetre_info.destroy()
        creation_f()
        
        
    def afficher_cartes():
        image_cartes = PhotoImage(file="./Photos/cartes.png")
        label_image = Label(fenetre_info, image=image_cartes)
        label_image.image = image_cartes
        label_image.place(relx=0.5, rely=0.6, anchor="center")
        label_image.after(5000, label_image.destroy)
        
    def afficher_biomes():
        
        image_biomes = PhotoImage(file="./Photos/biomes.png")
        label_biomes = Label(fenetre_info, image=image_biomes)
        label_biomes.image = image_biomes
        label_biomes.place(relx=0.5, rely=0.6, anchor="center")
        label_biomes.after(5000, label_biomes.destroy)
    
    
    def afficher_regles():
        texte_regles = "Voici les règles du jeu :\n\n1. Votre objtectif principal et d'etre le dernier survivant sur le plateau \n2. Vous pouvez déplacez votre pion d'une case par tour\n3. Lorsque vous etes sur la meme case qu'un autre joueur un combat se lance\n4. Vos statistiques de personnages sont données aléatoirement en début de partie\n"  # Règles
        label_regles = Label(fenetre_info, text=texte_regles, font=("Arial", 12), bg="white", fg="black", justify="center")
        label_regles.pack()
        label_regles.place(relx=0.5, rely=0.6, anchor="center")
        label_regles.after(30000, label_regles.destroy)
        
    def afficher_credits():
        texte_credits = "Ce jeu a été créé par Sergent Lucas \n\nétudiant de 2ème année en BUT Informatique dans le cadre d'une SAE\n\n Toutes les photos utilisées ont étaient générées par une Intelligence Artificielle nommée \n\nleonardo.ai"  # Crédits 
        label_credits = Label(fenetre_info, text=texte_credits, font=("Arial", 12), bg="white", fg="black", justify="center")
        label_credits.pack()
        label_credits.place(relx=0.5, rely=0.6, anchor="center")
        label_credits.after(30000, label_credits.destroy)
        
    
    def changer_couleur(event):
        event.widget.config(bg="gray")
        
        
    def remettre_couleur(event):
        event.widget.config(bg="#2d2d2d")

    fenetre_info = Tk()
    fenetre_info.attributes('-fullscreen', True)
    fond = PhotoImage(file="./Photos/fond_info.png")
    can = Canvas(fenetre_info, width=1920, height=1080)
    can.pack()
    can.create_image(0, 0, anchor=NW, image=fond)


    cartes = Button(fenetre_info, text="Cartes", command=afficher_cartes)
    cartes.pack()
    cartes.place(relx=0.3, rely=0.30, anchor="center")
    cartes.config(height=2, width=25, font=("Arial", 10), bg="#2d2d2d", fg="white")
    cartes.bind("<Enter>", changer_couleur)
    cartes.bind("<Leave>", remettre_couleur)

    regles = Button(fenetre_info, text="Règles", command=afficher_regles)
    regles.pack()
    regles.place(relx=0.7, rely=0.30, anchor="center")
    regles.config(height=2, width=25, font=("Arial", 10), bg="#2d2d2d", fg="white")
    regles.bind("<Enter>", changer_couleur)
    regles.bind("<Leave>", remettre_couleur)

    retour = Button(fenetre_info, text="Retour", command=fermer_info)
    retour.pack()
    retour.place(relx=0.5, rely=0.90, anchor="center")
    retour.config(height=2, width=50, font=("Arial", 10), bg="#2d2d2d", fg="white")
    retour.bind("<Enter>", changer_couleur)
    retour.bind("<Leave>", remettre_couleur)
    
    biomes = Button(fenetre_info, text="Biomes", command=afficher_biomes)
    biomes.pack()
    biomes.place(relx=0.5, rely=0.30, anchor="center")
    biomes.config(height=2, width=25, font=("Arial", 10), bg="#2d2d2d", fg="white")
    biomes.bind("<Enter>", changer_couleur)
    biomes.bind("<Leave>", remettre_couleur)
    
    # ajout un boutton en bas de la fenetre pour les credits :
    
    credits = Button(fenetre_info, text="Credits", command=afficher_credits)
    credits.pack()
    credits.place(relx=0.5, rely=0.80, anchor="center")
    credits.config(height=2, width=50, font=("Arial", 10), bg="#2d2d2d", fg="white")
    credits.bind("<Enter>", changer_couleur)
    credits.bind("<Leave>", remettre_couleur)
    
    

    fenetre_info.mainloop()

creation_f()