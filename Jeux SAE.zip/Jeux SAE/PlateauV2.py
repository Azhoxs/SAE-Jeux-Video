import tkinter as tk
import random


class PlateauJeu(tk.Tk):
    def __init__(self):
        super().__init__()
        

        self.joueur_actif = 0

        self.taille_case = 60  # Taille d'une case
        self.nb_cases = 15  # Nombre de cases par côté

        # Mettre la fenêtre en plein écran
        self.attributes('-fullscreen', True)
        self.configure(bg="#2d2d2d")

        # Choisir aléatoirement un biome et mettre à jour les couleurs du plateau
        self.choisir_biome()

        

        # Centrer le plateau de jeu au milieu de l'écran
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        plateau_width = self.nb_cases * self.taille_case
        plateau_height = self.nb_cases * self.taille_case
        self.geometry(f"{plateau_width}x{plateau_height}+{screen_width // 2 - plateau_width // 2}+{screen_height // 2 - plateau_height // 2}")
        

        # Afficher le nom du biome
        self.label_biome = tk.Label(self, text=f"Biome actuel : {self.biome}", font=("Arial", 16), bg="#2d2d2d", fg="white")
        self.label_biome.pack(pady=10)
        

        self.canvas = tk.Canvas(self, width=plateau_width, height=plateau_height, bg=self.plateau_couleur)
        self.canvas.pack()


        self.personnages = []
        self.personnage_selectionne = None
        self.x_selectionne = None
        self.y_selectionne = None
        

        self.couleurs_disponibles = ['#27D4FE', '#31FE27', '#F10B0B', '#FFF700']
        random.shuffle(self.couleurs_disponibles)  # Mélanger les couleurs aléatoirement
        


        self.emplacements_murs = set()  # Emplacements des murs (coordonnées x, y)


        self.forces = []  # Forces des personnages
        self.vies = []    # Vies des personnages
        
        
        self.j_actif = tk.Label(self, text=f"Tour du joueur : {self.joueur_actif + 1}", font=("Arial", 16), fg=self.couleurs_disponibles[self.joueur_actif], bg="#2d2d2d")
        self.j_actif.pack(pady=10)


        self.creer_plateau()
        self.creer_personnages()
        self.ajouter_murs_aleatoires()


        # Placer le bouton quitter en haut à droite
        self.quitter_button = tk.Button(self, text="X", bg="red", fg="white", font=("Arial", 12), command=self.quitter)
        self.quitter_button.place(x=screen_width - 40, y=10, width=30, height=30)



    def choisir_biome(self):
        self.biome = random.choice(["Désert", "Neige", "Océan", "Nuit"])

        if self.biome == "Désert":
            self.plateau_couleur = "#e0cda9"
        elif self.biome == "Neige":
            self.plateau_couleur = "#E2FFFA"
        elif self.biome == "Océan":
            self.plateau_couleur = "#418FFF"
        elif self.biome == "Nuit":
            self.plateau_couleur = "purple"



    def creer_plateau(self):
        for x in range(0, self.nb_cases * self.taille_case, self.taille_case):
            for y in range(0, self.nb_cases * self.taille_case, self.taille_case):
                self.canvas.create_rectangle(
                    x, y, x + self.taille_case, y + self.taille_case, fill=self.plateau_couleur)



    def ajouter_murs_aleatoires(self):
        # Nombre de murs à ajouter (vous pouvez changer ce nombre selon vos besoins)
        nombre_murs = 50

        for _ in range(nombre_murs):
            # Générer des coordonnées de mur aléatoires
            x = random.randint(1, self.nb_cases - 1)
            y = random.randint(1, self.nb_cases - 1)

            # Vérifier que les coordonnées ne correspondent pas à un emplacement de pion ou à proximité
            while (x, y) in [(self.canvas.coords(personnage)[0] // self.taille_case, self.canvas.coords(personnage)[1] // self.taille_case) for personnage in self.personnages] or \
                any(abs(x - px) <= 1 and abs(y - py) <= 1 for px, py in [(self.canvas.coords(personnage)[0] // self.taille_case, self.canvas.coords(personnage)[1] // self.taille_case) for personnage in self.personnages]) or \
                (x, y) in self.emplacements_murs:
                x = random.randint(1, self.nb_cases - 1)
                y = random.randint(1, self.nb_cases - 1)

            # Coordonnées du coin supérieur gauche du mur
            x_coord = x * self.taille_case
            y_coord = y * self.taille_case

            # Ajouter l'emplacement du mur à la liste des emplacements de murs
            self.emplacements_murs.add((x, y))

            # Dessiner le mur
            self.canvas.create_rectangle(
                x_coord, y_coord, x_coord + self.taille_case, y_coord + self.taille_case, fill="#353535")



    def calculer_deplacements_possibles(self, x, y):
        deplacements_possibles = [(x+1, y), (x-1, y), (x, y+1), (x, y-1)]
        return [(x*self.taille_case, y*self.taille_case) for x, y in deplacements_possibles]
    

    def afficher_deplacements_possibles(self, personnage):
        x, y, _, _ = self.canvas.coords(personnage)
        x, y = x // self.taille_case, y // self.taille_case
        deplacements_possibles = self.calculer_deplacements_possibles(x, y)


        for coord_x, coord_y in deplacements_possibles:
            
            # Vérifier si la case est un mur
            if (coord_x // self.taille_case, coord_y // self.taille_case) in self.emplacements_murs:
                continue  # Ne pas afficher le déplacement possible si c'est un mur

            if 0 <= coord_x < self.nb_cases * self.taille_case and 0 <= coord_y < self.nb_cases * self.taille_case:
                x_center = coord_x + self.taille_case / 2
                y_center = coord_y + self.taille_case / 2
                radius = self.taille_case / 2
                self.canvas.create_oval(
                    x_center - radius, y_center - radius, x_center + radius, y_center + radius,
                    fill="#7C7C7C", outline="#7C7C7C", tags="deplacement_possible")
                self.canvas.tag_bind("deplacement_possible", "<Button-1>", self.clic_sur_case)
                
                

    def clic_sur_pion(self, event):
        
        # Vérifie que le joueur actif peut déplacer que son personnage
        
        if self.canvas.find_withtag("current") != (self.personnages[self.joueur_actif],):
            return
        
        
        self.canvas.delete("deplacement_possible")
        for personnage in self.personnages:
            if self.canvas.find_withtag("current") == (personnage,):
                self.afficher_deplacements_possibles(personnage)
                self.personnage_selectionne = personnage
                self.x_selectionne, self.y_selectionne, _, _ = self.canvas.coords(personnage)
                return
            


    def ouvrir_fenetre_attaque(self, couleur_personnage):
        fenetre_attaque = tk.Toplevel(self)
        fenetre_attaque.title("Fenêtre d'attaque")

        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        fenetre_attaque.geometry(f"400x200+{screen_width // 2 - 400 // 2}+{screen_height // 3 - 200 // 2}")

        label_attaque = tk.Label(fenetre_attaque, text="Attaque en cours", font=("Arial", 16))
        label_attaque.pack(pady=20)


        # affiche la couleur du joueur actif qui attaque
        canvas_attaquant = tk.Canvas(fenetre_attaque, width=20, height=20, bg=self.couleurs_disponibles[self.joueur_actif])
        canvas_attaquant.pack(side=tk.LEFT, padx=20)
        
        
        # affiche la couleur du joueur qui se fait attaquer dans la fenetre 
        canvas_attaque = tk.Canvas(fenetre_attaque, width=20, height=20, bg=couleur_personnage)
        canvas_attaque.pack(side=tk.RIGHT, padx=20)
    

        bouton_attaquer = tk.Button(fenetre_attaque, text="Attaquer")
        bouton_attaquer.pack()
        
        # quand on clique sur le bouton attaquer on enleve 180 points de vie au personnage attaqué
        bouton_attaquer.bind("<Button-1>", lambda event: self.enlever_vie_personnage(couleur_personnage))
        
        
    def enlever_vie_personnage(self, couleur_personnage):
            
            # recupere l'index du personnage qui se fait attaquer
            index_personnage = self.couleurs_disponibles.index(couleur_personnage)
            
            # enleve 180 points de vie au personnage qui se fait attaquer
            self.vies[index_personnage] -= 180
            
            # si la vie du personnage est inférieur ou égale à 0 on le supprime
            if self.vies[index_personnage] <= 0:
                self.canvas.delete(self.personnages[index_personnage])
                self.personnages.pop(index_personnage)
                self.vies.pop(index_personnage)
                self.forces.pop(index_personnage)
                self.couleurs_disponibles.pop(index_personnage)


                # si il ne reste plus qu'un personnage on affiche le gagnant
                if len(self.personnages) == 1:
                    self.afficher_gagnant()
                
            self.canvas.delete("deplacement_possible")
            self.x_selectionne, self.y_selectionne = None, None
            self.personnage_selectionne = None
            
            # change de tour à chaque attaque
            self.joueur_actif = (self.joueur_actif + 1) % len(self.personnages)
            self.j_actif.config(text=f"Tour du joueur : {self.joueur_actif + 1}")
            
            # met en couleur le joueur actif de la couleur de son personnage
            self.j_actif.config(fg=self.couleurs_disponibles[self.joueur_actif])
            
    def afficher_gagnant(self):
        fenetre_gagnant = tk.Toplevel(self)
        fenetre_gagnant.title("Fenêtre du gagnant")

        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        fenetre_gagnant.geometry(f"400x200+{screen_width // 2 - 400 // 2}+{screen_height // 3 - 200 // 2}")

        label_gagnant = tk.Label(fenetre_gagnant, text=f"Le gagnant est le joueur {self.joueur_actif + 1}", font=("Arial", 16))
        label_gagnant.pack(pady=20)
        
        bouton_quitter = tk.Button(fenetre_gagnant, text="Quitter", command=self.quitter)
        bouton_quitter.pack()
        
        bouton_rejouer = tk.Button(fenetre_gagnant, text="Rejouer", command=self.rejouer)
        bouton_rejouer.pack()
        
    def rejouer(self):
        self.destroy()
        app = PlateauJeu()
        app.mainloop()    
        

    def clic_sur_case(self, event):
        x, y = event.x // self.taille_case, event.y // self.taille_case

        # Vérifier si la case vers laquelle on veut se déplacer est un pion
        for personnage in self.personnages:
            px, py, _, _ = self.canvas.coords(personnage)
            px, py = px // self.taille_case, py // self.taille_case
            if (x, y) == (px, py) and personnage != self.personnage_selectionne:
                
                # recupere la couleur du personnage qui se fait attaquer
                couleur_personnage = self.canvas.itemcget(personnage, "fill")
                
                # Collision détectée, ouvrez la fenêtre d'attaque
                self.ouvrir_fenetre_attaque(couleur_personnage)
                return
            

        # Le reste du code pour déplacer le personnage
        x_current, y_current, _, _ = self.canvas.coords(self.personnage_selectionne)
        new_x_coord = x * self.taille_case if 0 <= x < self.nb_cases and abs(x - (x_current // self.taille_case)) <= 1 else x_current
        new_y_coord = y * self.taille_case if 0 <= y < self.nb_cases and abs(y - (y_current // self.taille_case)) <= 1 else y_current

        self.deplacer_personnage(self.personnage_selectionne, new_x_coord, new_y_coord)
        self.canvas.delete("deplacement_possible")
        self.x_selectionne, self.y_selectionne = None, None
        self.personnage_selectionne = None

         

    def creer_personnage(self, x, y, couleur):
        x_coord = x * self.taille_case + self.taille_case / 2
        y_coord = y * self.taille_case + self.taille_case / 2
        rayon = self.taille_case / 2
        personnage = self.canvas.create_oval(
            x_coord - rayon, y_coord - rayon, x_coord + rayon, y_coord + rayon, fill=couleur)
        self.canvas.tag_bind(personnage, "<Button-1>", self.clic_sur_pion)
        return personnage



    def deplacer_personnage(self, personnage, x, y):
        self.canvas.coords(personnage, x, y, x + self.taille_case, y + self.taille_case)
        
        # change de tour à chaque déplacement
        self.joueur_actif = (self.joueur_actif + 1) % len(self.personnages)
        self.j_actif.config(text=f"Tour du joueur : {self.joueur_actif + 1}")
        
        # met en couleur le joueur actif de la couleur de son personnage
        self.j_actif.config(fg=self.couleurs_disponibles[self.joueur_actif])
    

    def creer_personnages(self):
        coins = [(0, 0), (self.nb_cases - 1, 0), (0, self.nb_cases - 1), (self.nb_cases - 1, self.nb_cases - 1)]
        for i in range(len(coins)):
            x, y = coins[i]
            couleur = self.couleurs_disponibles[i]
            personnage = self.creer_personnage(x, y, couleur)

            # Générer des valeurs aléatoires pour la force et la vie (entre 150 et 200)
            force = random.randint(60, 90)
            vie = random.randint(100, 130)


            # Stocker les valeurs dans les listes correspondantes
            self.forces.append(force)
            self.vies.append(vie)
            

            self.personnages.append(personnage)
            

    def quitter(self):
        self.destroy()

if __name__ == "__main__":
    app = PlateauJeu()
    app.mainloop()
